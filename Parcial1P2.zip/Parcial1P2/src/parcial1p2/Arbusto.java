/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1p2;

/**
 *
 * @author Luciano
 */
public class Arbusto extends Planta implements Podar{
    
    private final double DENSIDAD_MIN = 1;
    private final double DENSIDAD_MAX = 10;
    private double densidad;

    public Arbusto(double densidad, String nombre, String ubicacion, Clima climaProspero) {
        super(nombre, ubicacion, climaProspero);
        validarDensidad(densidad);
        this.densidad = densidad;
    }
    
    private void validarDensidad(double d){
        if(d < DENSIDAD_MIN || d > DENSIDAD_MAX){
            throw new IllegalArgumentException("Densidad no valida, minimo " + DENSIDAD_MIN + " maximo " + DENSIDAD_MAX);
        }
    }

    @Override
    public String toString() {
        return "nombre: " + super.getNombre() + ", ubicacion: " + super.getUbicacion() + ", climaProspero: " + super.getClimaProspero() + ", densidad: " + densidad;
    }

    @Override
    public void podar() {
        System.out.println("Arbusto podado");
    }
    
 

    
    
    
    
    
}


