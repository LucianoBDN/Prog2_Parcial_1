/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package parcial1p2;

/**
 *
 * @author Luciano
 */
public interface Podar {
    
    public abstract void podar();
}
