/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1p2;

import java.util.Objects;


public abstract class Planta {
    
    private final String nombre;
    private String ubicacion;
    private final Clima climaProspero;

    public Planta(String nombre, String ubicacion, Clima climaProspero) {
        validarString(nombre);
        validarString(ubicacion);
        
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.climaProspero = climaProspero;
    }

    private void validarString(String texto) {
    if (texto == null || texto.isEmpty()) {
        throw new IllegalArgumentException("El argumento no puede ser nulo o vacio.");
        }
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public Clima getClimaProspero() {
        return climaProspero;
    }
    
    
    
    
    
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Planta other = (Planta) o;

        return other.nombre.equals(this.nombre)
                && other.ubicacion.equals(this.ubicacion) ;
    
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre, ubicacion);
    }
    

    @Override
    public String toString() {
        return "nombre: " + nombre + ", ubicacion: " + ubicacion + ", climaProspero: " + climaProspero;
    }
    
    
}
