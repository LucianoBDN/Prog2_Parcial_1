/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parcial1p2;

/**
 *
 * @author Luciano
 */
public class Parcial1P2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Arbol a = new Arbol(1.4, "Roble", "zona norte", Clima.TEMPLADO);
        Flor f = new Flor(Florecimiento.PRIMAVERA, "shosa", "piso", Clima.SECO);
        
        JardinBotanico j = new JardinBotanico();
        try{

            j.agregarPlanta(f);
            j.agregarPlanta(ab);
            Arbol a2 = new Arbol(1.4, "Roble", "Zona norte", Clima.TEMPLADO);
            j.agregarPlanta(a2);
            Arbusto ab = new Arbusto(0, "arbustin", "medianera", Clima.SECO);
        
        }catch(IllegalArgumentException ex){
            System.out.println(ex.getMessage());
           
        }catch(PlantaExisteException e) {
            System.out.println(e);
        }
        
        
        j.mostarPlantas();
        j.podarPlantas();
        
    }
    
}
