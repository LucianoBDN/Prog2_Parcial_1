/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1p2;

/**
 *
 * @author Luciano
 */
public class Arbol extends Planta implements Podar{
    
    private double alturaMaxima;

    public Arbol(double alturaMaxima, String planta, String ubicacion, Clima climaProspero) {
        super(planta, ubicacion, climaProspero);
        validarDouble(alturaMaxima);
        this.alturaMaxima = alturaMaxima;
    }

    private void validarDouble(double e) {
    if (e < 0) {
        throw new IllegalArgumentException("Altura no valida, solo numero positivos");
        }    
    }    
    
    @Override
    public String toString() {
        return "nombre: " + super.getNombre() + ", ubicacion: " + super.getUbicacion() + ", climaProspero: " + super.getClimaProspero() + ", alturaMaxima: " + alturaMaxima ;
    }

    @Override
    public void podar() {
        System.out.println("Arbol podado");
    }
    
    
    
    
    
    
    
}
