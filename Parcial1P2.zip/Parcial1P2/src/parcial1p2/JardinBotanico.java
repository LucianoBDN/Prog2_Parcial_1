/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1p2;

import java.util.ArrayList;

/**
 *
 * @author Luciano
 */
public class JardinBotanico {
    
    private ArrayList<Planta>plantas;

    public JardinBotanico() {
        this.plantas = new ArrayList<>();
    }
    
    
    public void agregarPlanta(Planta planta){
        if (planta == null) {
            throw new NullPointerException("El objeto es nulo.");
        }
        if(plantas.contains(planta)){
            throw new PlantaExisteException();
        }
        plantas.add(planta);
    }
    
    public void mostarPlantas(){
        if (plantas.isEmpty()){
            System.out.println("No hay plantas");
        } else {
            for (Planta p : plantas){
                System.out.println(p);
            }
        }
    }
    
    public void podarPlantas(){
        for (Planta planta : plantas) {
            if (planta instanceof Podar p){
                p.podar();
            } else {
                System.out.println(planta.getNombre() + "no se puede podar una flor");
            }
            
        }
    }
    
}
