/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1p2;

/**
 *
 * @author Luciano
 */
public class PlantaExisteException extends RuntimeException{
    public static final String MESSAGE = "Planta ya esta en el Jardin";
    
    public PlantaExisteException(){
        super(MESSAGE);
    }
}

