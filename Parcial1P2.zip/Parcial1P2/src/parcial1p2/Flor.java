/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcial1p2;

/**
 *
 * @author Luciano
 */
public class Flor extends Planta{
    
    private Florecimiento tempFlorecimiento;

    public Flor(Florecimiento tempFlorecimiento, String nombre, String ubicacion, Clima climaProspero) {
        super(nombre, ubicacion, climaProspero);
        this.tempFlorecimiento = tempFlorecimiento;
    }

    @Override
    public String toString() {
        return "nombre: " + super.getNombre() + ", ubicacion: " + super.getUbicacion() + ", climaProspero: " + super.getClimaProspero() + ", tempFlorecimiento: " + tempFlorecimiento;
    }
    
    
    
    
    
    
}
